
</div>
			
		
			<div style='clear: both'></div>
		</div>
		<div class='push'></div>
	</div>
	
	<div class='footerDiv'>
	
		Powered By: <a href='http://www.bluethrust.com' target='_blank'>Bluethrust Clan Scripts v4</a> - <a href='http://www.bluethrust.com/themes'>GTA Beach Theme</a><br>
		&copy; Copyright <?php echo date("Y")." ".$websiteInfo['clanname']; ?>
	
	</div>
	
	<?php include($prevFolder."themes/include_footer.php"); ?>
</body>
</html>