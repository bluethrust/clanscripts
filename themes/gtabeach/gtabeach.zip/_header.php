<?php

include($prevFolder."themes/gtabeach/_logindisplay.php");
include($prevFolder."themes/include_header.php");
include($prevFolder."themes/gtabeach/_menus.php");
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<title><?php echo $PAGE_NAME.$CLAN_NAME; ?></title>
		<link rel='stylesheet' type='text/css' href='<?php echo $MAIN_ROOT; ?>themes/gtabeach/jqueryui/jquery-ui-1.8.17.custom.css'>
		<link href='https://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
		<script type='text/javascript' src='<?php echo $MAIN_ROOT; ?>js/jquery-1.6.4.min.js'></script>
		<script type='text/javascript' src='<?php echo $MAIN_ROOT; ?>js/jquery-ui-1.8.17.custom.min.js'></script>
		<link rel='stylesheet' type='text/css' href='<?php echo $MAIN_ROOT; ?>themes/gtabeach/btcs4.css'>
		<link rel='stylesheet' type='text/css' href='<?php echo $MAIN_ROOT; ?>themes/gtabeach/style.css'>
		<script type='text/javascript' src='<?php echo $MAIN_ROOT; ?>themes/gtabeach/gtabeach.js'></script>
		<script type='text/javascript' src='<?php echo $MAIN_ROOT; ?>js/main.js'></script>
		<script type='text/javascript' src='<?php echo $MAIN_ROOT; ?>js/imageslider.js'></script>
		
			<?php if(isset($EXTERNAL_JAVASCRIPT))
			        echo $EXTERNAL_JAVASCRIPT; ?>
	</head>
<body>
	<div class='cloudBG'></div>
	<div class='bottom-right-image'></div>
	<div class='bottom-left-image'></div>
	
	<div class='left-character-1' id='leftCharacterBG-1' style='display: none'></div>
	<div class='right-character-1' id='rightCharacterBG-1' style='display: none'></div>
	
	<div class='left-character-2' id='leftCharacterBG-2' style='display: none'></div>
	<div class='right-character-2' id='rightCharacterBG-2' style='display: none'></div>
	
	
	<?php
		if($LOGGED_IN && $arrLoginInfo['pmAlert'] == 1) {
			echo "
				<div id='starsPMAlert'>
					<img src='".$MAIN_ROOT."themes/gtabeach/images/layout/stars.gif'>
				</div>
			";
		}
	?>
	<div id='phoneDiv'>	
		
		<?php dispMenu(2); ?>
		
		<div id='phoneCloseDiv'></div>
	
	</div>
	
	<div class='wrapper'>
		<div class='headerDiv'>
		
			<img src='<?php echo $MAIN_ROOT; ?>themes/gtabeach/images/logo.png'>	
		
		</div>
		
		<div class='topMenuDiv'>
			<?php dispMenu(0); ?>		
		</div>
		
		<div class='mainContentDiv'>
			<div class='rightContentDiv'>
				
				<?php dispMenu(1); ?>		
				
				<div style='clear: both'></div>
			</div>
			<div class='leftContentDiv'>